# password-manager
CRUD operations passwords
Client: Angular
Server: Spring boot

# commands 
Install angular: npm install -g @angular/cli.

# Database
Download SQL Work bench.

# Server 
Download the Spring tool suite in eclipse IDE.
