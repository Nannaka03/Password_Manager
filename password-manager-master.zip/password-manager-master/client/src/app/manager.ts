export class Manager {
    id: number;
    url: string;
    username: string;
    password: string;
    
}